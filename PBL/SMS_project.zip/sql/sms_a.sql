-- Shopping Mall Sales Management System - database schema
-- Run once in MySQL Workbench / mysql client.
CREATE DATABASE IF NOT EXISTS sms_a;
USE sms_a;

CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL            -- 'Admin' or 'Cashier'
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50),
    price DECIMAL(10,2) NOT NULL,
    stock_qty INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sales (
    id INT PRIMARY KEY AUTO_INCREMENT,
    sale_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    cashier_id INT NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    discount DECIMAL(10,2) DEFAULT 0,
    tax DECIMAL(10,2) DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL,
    payment_mode VARCHAR(20) NOT NULL,   -- 'Cash' or 'Card'
    FOREIGN KEY (cashier_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sale_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    sale_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB;

-- Starter data
INSERT INTO users(username,password,role) VALUES
 ('admin','admin123','Admin'),
 ('cashier','cashier123','Cashier');

INSERT INTO products(name,category,price,stock_qty) VALUES
 ('Rice 1kg','Grocery',65.00,100),
 ('Soybean Oil 1L','Grocery',170.00,50),
 ('Soap','Personal Care',45.00,80),
 ('Notebook','Stationery',60.00,40);
