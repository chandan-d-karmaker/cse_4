SMSMS - Setup in Apache NetBeans
1. Run sql/sms_a.sql in MySQL (creates database sms_a, tables, 2 users, 4 products).
2. NetBeans: File > New Project > Java with Ant > Java Application (untick "Create Main Class").
3. Copy the three folders sms_model, sms_con, sms_view from src/ into your project's Source Packages.
   (Replace your old user_model / user_con / user_view.)
4. Right-click Libraries > Add JAR/Folder > mysql-connector-j-8.x.jar.
5. Edit URL/USER/PASS in sms_model/db_connection.java if your MySQL settings differ.
6. Right-click sms_view/login_view.java > Run File.

Logins: admin / admin123  (Products, Users, Sales History)
        cashier / cashier123  (POS, Sales History)
